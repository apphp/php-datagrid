DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Морате да изаберете један или више редова да спроведе ову операцију!";
DGVocabulary._MSG["alert_perform_operation"] = "Да ли сте сигурни да желите да спроведе ову операцију?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Да ли сте сигурни да желите да спроведе операцију брисања?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Да ли сте сигурни да желите да спроведе операцију клон?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Ова операција је блокиран у демо верзији!";
DGVocabulary._MSG["cookies_required"] = "Ова операција захтева да ваш бровсер не прихвата колачиће? Молимо Вас да укључите колачиће прихватању.";
DGVocabulary._MSG["exporting_alert"] = "Да ли желите да извезете датагрид садржаја у фајлу";
DGVocabulary._MSG["extension_not_allowed"] = "Фајлови са одабраним проширење нису дозвољени.";
DGVocabulary._MSG["need_upload_file"] = "Морате да отпремите датотеке или слику пре ажурирања! Кликните на везу Отпреми.";
DGVocabulary._MSG["please_reenter"] = "Молимо Вас да поново унесете!";
DGVocabulary._MSG["upload_file_size_alert"] = "Датотеке коју покушавате да отпремите је већа од максимално дозвољене величине: ";
