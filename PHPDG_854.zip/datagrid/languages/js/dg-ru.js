DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Пожалуйста, выбрите одину или несколько записей для выполнения этой операции!";
DGVocabulary._MSG["alert_perform_operation"] = "Вы действительно хотите выполнить эту операцию?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Вы действительно хотите выполнить операцию удаления?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Вы действительно хотите выполнить операцию коприрования?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Эта операция заблокирована в демо-версии!";
DGVocabulary._MSG["cookies_required"] = "Эта операция требует поддержки cookies вашим браузерером! Пожалуйста, включите поддержку cookies.";
DGVocabulary._MSG["exporting_alert"] = "Вы действительно хотите экспортировать содержимое в файл";
DGVocabulary._MSG["extension_not_allowed"] = "Файлы с выбраным расширением не могут быть загружены.";
DGVocabulary._MSG["need_upload_file"] = "Сначала необходимо загрузить файл или изображение! Пожалуйста, нажмите на ссылку Отправить.";
DGVocabulary._MSG["please_reenter"] = "Пожалуйста, введите другое значение!";
DGVocabulary._MSG["upload_file_size_alert"] = "Файл, который вы пытаетесь загрузить превышает максимально допустимый размер: ";
