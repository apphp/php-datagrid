<?php
    $rowColor = array();
    $rowColor[0] = '#F8F7EF'; // odd row color 
    $rowColor[1] = '#F8F7EF'; // even row color
    $rowColor[2] = '#F2F1E4'; // odd row color in main colomn
    $rowColor[3] = '#F2F1E4'; // even row color in main colomn
    $rowColor[4] = '#e4e2d3'; // row mouse over lighting 
    $rowColor[5] = '#E7E3C7'; // on mouse click 
    $rowColor[6] = '#FFCFB4'; // header (th main) column
    $rowColor[7] = '#e4e2d3'; // selected row mouse over lighting
    $rowColor[8] = '#f1f0e8';
    $rowColor[9] = '#f1f0e8';
