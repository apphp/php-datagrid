DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "U hebt een of meer rijen te selecteren voor de uitvoering van deze operatie!";
DGVocabulary._MSG["alert_perform_operation"] = "Weet u zeker dat u wilt verrichten deze operatie?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Ben je zeker dat je wilt uitvoeren operatie verwijderen?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Ben je zeker dat je wilt uitvoeren kloon operatie?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Deze operatie is geblokkeerd in de demo versie!";
DGVocabulary._MSG["cookies_required"] = "Deze operatie vereist dat uw browser cookies accepteert! Aangeraden over cookies accepteren.";
DGVocabulary._MSG["exporting_alert"] = "Wil je datagrid inhoud exporteren naar het bestand";
DGVocabulary._MSG["extension_not_allowed"] = "Bestanden met geselecteerde extensie zijn niet toegestaan.";
DGVocabulary._MSG["need_upload_file"] = "U moet uploaden of een afbeelding voordat update! Klik op Upload link.";
DGVocabulary._MSG["please_reenter"] = "Probeer opnieuw in te voeren!";
DGVocabulary._MSG["upload_file_size_alert"] = "Het bestand dat u probeert te uploaden is groter dan de maximum toegestane grootte: ";
