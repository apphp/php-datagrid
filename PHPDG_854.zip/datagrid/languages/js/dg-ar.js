DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "لديك لاختيار واحد أو أكثر من الصفوف لتنفيذ هذه العملية!";
DGVocabulary._MSG["alert_perform_operation"] = "هل أنت متأكد أنك تريد القيام بهذه العملية؟";
DGVocabulary._MSG["alert_perform_operation_delete"] = "هل أنت متأكد أنك تريد تنفيذ عملية الحذف؟";
DGVocabulary._MSG["alert_perform_operation_clone"] = "هل أنت متأكد أنك تريد تنفيذ عملية استنساخ؟";
DGVocabulary._MSG["alert_blocked_in_demo"] = "تم حظر هذه العملية في النسخة التجريبية!";
DGVocabulary._MSG["cookies_required"] = "تتطلب هذه العملية أن المتصفح يقبل الكوكيز! يرجى بدوره على ملفات تعريف الارتباط الموافقة.";
DGVocabulary._MSG["exporting_alert"] = "هل تريد تصدير datagrid المحتوى في ملف";
DGVocabulary._MSG["extension_not_allowed"] = "لا يسمح الملفات مع التمديد المحدد..";
DGVocabulary._MSG["need_upload_file"] = "يجب تحميل الملف أو الصورة قبل التحديث! الرجاء الضغط على وصلة تحميل.";
DGVocabulary._MSG["please_reenter"] = "الرجاء إعادة إدخال!";
DGVocabulary._MSG["upload_file_size_alert"] = "الملف الذي تحاول تحميل أكبر من حجم الحد الأقصى المسموح به :";
