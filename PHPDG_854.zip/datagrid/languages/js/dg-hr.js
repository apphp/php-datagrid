DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Morate izabrati jedan ili više redaka za izvršavanje ove operacije!";
DGVocabulary._MSG["alert_perform_operation"] = "Jeste li sigurni da želite izvršiti ovu operaciju?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Jeste li sigurni da želite izvršiti brisanje operaciju?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Jeste li sigurni da želite provesti klon operaciju?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Ovaj rad je blokiran u demo verzija!";
DGVocabulary._MSG["cookies_required"] = "Ova operacija zahtijeva da vaš preglednik prihvaća kolačiće! Molimo uključite kolačiće prihvaćanju.";
DGVocabulary._MSG["exporting_alert"] = "Želite li izvoziti DataGrid sadržaj u datoteku";
DGVocabulary._MSG["extension_not_allowed"] = "Datoteke s odabranim produžetak nisu dopušteni.";
DGVocabulary._MSG["need_upload_file"] = "Morate upload datoteke ili slike prije update! Molimo kliknite na Upload link.";
DGVocabulary._MSG["please_reenter"] = "Molimo unesite ponovno!";
DGVocabulary._MSG["upload_file_size_alert"] = "Datoteka koju pokušavate učitati je veća od maksimalno dopuštene veličine: ";
