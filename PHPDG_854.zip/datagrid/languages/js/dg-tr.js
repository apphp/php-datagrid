DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Bu işlemi gerçekleştirmek için bir veya daha fazla satır seçmek zorundasınız!";
DGVocabulary._MSG["alert_perform_operation"] = "Are sen bu işlemi istediğinizden emin misiniz?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Eğer silme işlemi yapmak istediğinizden emin misiniz?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Eğer klon operasyon yapmak istediğinizden emin misiniz?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Bu işlemi Demo Version engellenir!";
DGVocabulary._MSG["cookies_required"] = "Bu işlem tarayıcınızda çerezleri kabul gerektirir! Lütfen çerezleri kabul açın.";
DGVocabulary._MSG["exporting_alert"] = "Eğer dosyaya datagrid içeriğini vermek ister misiniz";
DGVocabulary._MSG["extension_not_allowed"] = "Seçilen uzantısına sahip dosyalar kabul edilmez.";
DGVocabulary._MSG["need_upload_file"] = "Sen güncellemeden önce dosya veya resim upload gerekir! Yükle bağlantısını tıklayın.";
DGVocabulary._MSG["please_reenter"] = "Lütfen yeniden girin!";
DGVocabulary._MSG["upload_file_size_alert"] = "Yüklemeye çalıştığınız dosya izin verilen maksimum boyutundan daha büyük: ";
