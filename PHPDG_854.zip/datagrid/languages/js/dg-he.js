DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "אתה צריך לבחור אחד או יותר שורות כדי לבצע פעולה זו!";
DGVocabulary._MSG["alert_perform_operation"] = "האם אתה בטוח שאתה רוצה לבצע את הפעולה?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "האם אתה בטוח שאתה רוצה לבצע פעולת מחיקה?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "האם אתה בטוח שאתה רוצה לבצע את הפעולה של שיבוט?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "פעולה זו חסומה בגרסת הדגמה!";
DGVocabulary._MSG["cookies_required"] = "פעולה זו דורשת הדפדפן מקבל עוגיות! בבקשה להפעיל את העוגיות לקבל.";
DGVocabulary._MSG["exporting_alert"] = "האם אתה רוצה לייצא את תוכן DataGrid לקובץ";
DGVocabulary._MSG["extension_not_allowed"] = "קבצים עם סיומת שנבחרו אינם מותרים.";
DGVocabulary._MSG["need_upload_file"] = "אתה חייב להעלות את הקובץ או התמונה לפני העדכון! אנא לחץ על הקישור טען.";
DGVocabulary._MSG["please_reenter"] = "נא להזין מחדש!";
DGVocabulary._MSG["upload_file_size_alert"] = "הקובץ שאתה מנסה להעלות גדול יותר מהגודל המרבי המותר: ";
