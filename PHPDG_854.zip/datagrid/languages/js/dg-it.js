DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Devi selezionare una o più righe di effettuare questa operazione!";
DGVocabulary._MSG["alert_perform_operation"] = "Sei sicuro di voler effettuare questa operazione?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Sei sicuro di voler effettuare l'operazione di eliminazione?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Sei sicuro di voler eseguire l'operazione clone?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Questa operazione è bloccato in versione demo!";
DGVocabulary._MSG["cookies_required"] = "Questa operazione richiede che il browser accetta i cookie! Si prega di attivare i cookies accettare.";
DGVocabulary._MSG["exporting_alert"] = "Vuoi datagrid esportare il contenuto nel file";
DGVocabulary._MSG["extension_not_allowed"] = "I file con estensione selezionati non sono ammessi.";
DGVocabulary._MSG["need_upload_file"] = "È necessario caricare il file o l'immagine prima di aggiornare! Fare clic sul link Carica.";
DGVocabulary._MSG["please_reenter"] = "Si prega di inserire nuovamente!";
DGVocabulary._MSG["upload_file_size_alert"] = "Il file che stai cercando di caricare è più grande di dimensione massima consentita: ";
