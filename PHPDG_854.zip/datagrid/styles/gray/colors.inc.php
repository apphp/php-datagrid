<?php
    $rowColor = array();
    $rowColor[0] = '#f9f9f9'; // odd row color 
    $rowColor[1] = '#f0f0f0'; // even row color
    $rowColor[2] = '#f0f0f0'; // odd row color in main colomn
    $rowColor[3] = '#dedede'; // even row color in main colomn
    $rowColor[4] = '#FEFFE8'; // row mouse over lighting 
    $rowColor[5] = '#FEFFE8'; // on mouse click 
    $rowColor[6] = '#dedede'; // header (th main) column
    $rowColor[7] = '#FEFFE8'; // selected row mouse over lighting
    $rowColor[8] = '#f9f9f9';
    $rowColor[9] = '#f9f9f9';
