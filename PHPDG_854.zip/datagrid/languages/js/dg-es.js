DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Tienes que seleccionar una o más filas para llevar a cabo esta operación!";
DGVocabulary._MSG["alert_perform_operation"] = "¿Estás seguro de que desea llevar a cabo esta operación?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "¿Está seguro que desea llevar a cabo la operación de eliminación?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "¿Está seguro que desea llevar a cabo operación de clonación?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Esta operación se bloquea en Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Esta operación requiere que su navegador acepte cookies! Please turn on aceptar cookies.";
DGVocabulary._MSG["exporting_alert"] = "¿Desea exportar contenido datagrid en el archivo";
DGVocabulary._MSG["extension_not_allowed"] = "Los archivos con extensión seleccionada no están permitidos.";
DGVocabulary._MSG["need_upload_file"] = "Debe cargar el archivo o la imagen antes de la actualización! Por favor, haga clic en el enlace Subir.";
DGVocabulary._MSG["please_reenter"] = "Por favor, vuelva a entrar!";
DGVocabulary._MSG["upload_file_size_alert"] = "El archivo que está intentando cargar es más grande que el tamaño máximo permitido: ";
