DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Sie müssen eine oder mehrere Zeilen markieren, um diese Operation durchzuführen!";
DGVocabulary._MSG["alert_perform_operation"] = "Sind Sie sicher, dass Sie diese Operation durchzuführen wollen?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Sind Sie sicher, dass die Durchführung Ihres Betrieb?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Sind Sie sicher, dass die Durchführung Klon-Betrieb?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Dieser Vorgang ist in der Demoversion gesperrt!";
DGVocabulary._MSG["cookies_required"] = "Diese Operation erfordert, dass Ihr Browser Cookies akzeptiert! Bitte schalten Sie 'Cookies akzeptieren' ein.";
DGVocabulary._MSG["exporting_alert"] = "Wollen Sie Datagrid Inhalt in die Datei exportieren";
DGVocabulary._MSG["extension_not_allowed"] = "Dateien mit ausgewählten Erweiterung sind nicht gestattet.";
DGVocabulary._MSG["need_upload_file"] = "Sie müssen die Datei hochladen! Bitte klicken Sie auf den Upload-Link.";
DGVocabulary._MSG["please_reenter"] = "Sie müssen Upload-Datei";
DGVocabulary._MSG["upload_file_size_alert"] = "Die Datei, die Sie hochladen möchten, ist größer als die maximal zulässige Größe: ";
