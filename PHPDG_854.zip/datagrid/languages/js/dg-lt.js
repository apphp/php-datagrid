DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Turite pasirinkti vieną ar daugiau eilučių atlikti šią operaciją!";
DGVocabulary._MSG["alert_perform_operation"] = "Ar tikrai norite atlikti šį veiksmą?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Ar tikrai norite atlikti ištrinti operacijos?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Ar tikrai norite atlikti klonas operacijos?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Ši operacija yra užblokuotas Demo versija!";
DGVocabulary._MSG["cookies_required"] = "Ši operacija reikalauja, kad jūsų naršyklė priima slapukus! Prašome įjungti slapukų priėmimą.";
DGVocabulary._MSG["exporting_alert"] = "Ar norite eksportuoti DataGrid turinį į failą";
DGVocabulary._MSG["extension_not_allowed"] = "Failai su pasirinktais pratęsti neleidžiama.";
DGVocabulary._MSG["need_upload_file"] = "Jūs turite nusiųsti failą ar vaizdo, prieš atnaujinti! Prašome spausti Siųsti nuorodą.";
DGVocabulary._MSG["please_reenter"] = "Įveskite iš naujo!";
DGVocabulary._MSG["upload_file_size_alert"] = "Failas, kurį bandote įkelti didesnis už maksimalų leistiną dydį: ";
