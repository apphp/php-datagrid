DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Morate izabrati jedan ili više redaka za izvršavanje ove operacije!";
DGVocabulary._MSG["alert_perform_operation"] = "Jeste li sigurni da želite izvršiti ovu operaciju?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Biztos benne, hogy szeretné elvégezni a törlési művelet?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Biztos benne, hogy szeretné elvégezni klónozási művelet?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Ez a művelet le van tiltva a Demo verzió!";
DGVocabulary._MSG["cookies_required"] = "Ova operacija zahtijeva da vaš preglednik prihvaća kolačiće! Molimo uključite kolačiće prihvaćanju.";
DGVocabulary._MSG["exporting_alert"] = "Szeretné exportálni DataGrid tartalmat a fájl";
DGVocabulary._MSG["extension_not_allowed"] = "Fájlok kiválasztott kiterjesztések nem megengedettek.";
DGVocabulary._MSG["need_upload_file"] = "Morate upload datoteke ili slike prije update! Molimo kliknite na Upload link.";
DGVocabulary._MSG["please_reenter"] = "Kérjük adja meg újra!";
DGVocabulary._MSG["upload_file_size_alert"] = "A kívánt fájl feltölteni nagyobb megengedett legnagyobb méret: ";
