DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Du er nødt til at vælge en eller flere rækker til at udføre denne handling!";
DGVocabulary._MSG["alert_perform_operation"] = "Er du sikker på du ønsker at udføre denne operation?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Er du sikker på du ønsker at udføre sletningen?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Er du sikker på du ønsker at udføre klone drift?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Denne operation er blokeret i Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Denne operation kræver, at din browser accepterer cookies! Slå om cookies acceptere.";
DGVocabulary._MSG["exporting_alert"] = "Ønsker du at eksportere DataGrid indhold i filen";
DGVocabulary._MSG["extension_not_allowed"] = "Filer med udvalgte udvidelse er ikke tilladt.";
DGVocabulary._MSG["need_upload_file"] = "Du skal uploade filen eller billedet, før opdatering! Klik på Upload link.";
DGVocabulary._MSG["please_reenter"] = "Indtast igen!";
DGVocabulary._MSG["upload_file_size_alert"] = "Den fil, du forsøger at uploade er større end den maksimalt tilladte størrelse: ";
