///////////////////////////////////////////////////////////////////////////////////
// 
// Advanced Power of PHP 
// ---------------------
// https://www.apphp.com
// 
// ApPHP DataGrid Pro (AJAX enabled)
//
// Version: 8.5.4
//
///////////////////////////////////////////////////////////////////////////////////

Thank you for using ApPHP.com software!
-----------------------------------------------------------------------------------

It's very easy to get started with ApPHP DataGrid Pro (AJAX enabled)!!!

1. Installation:
   docs/installation.html or
   https://www.apphp.com/php-datagrid/index.php?page=installation

2. Updating:
   docs/Updating.html or
   https://www.apphp.com/php-datagrid/index.php?page=updating

3. Getting started:
   docs/GettingStarted.html or 
   https://www.apphp.com/php-datagrid/index.php?page=getting-started


If you have any troubles, find some examples of code in the folder, named "examples" 
-----------------------------------------------------------------------------------
For more information visit: 
	site 	https://www.apphp.com/php-datagrid/index.php?page=examples
	forum 	http://www.apphp.net/forum/


