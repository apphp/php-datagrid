DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Você deve selecionar uma ou mais linhas para realizar esta operação!";
DGVocabulary._MSG["alert_perform_operation"] = "Tem certeza que quer realizar esta operação?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Tem certeza de que deseja realizar a operação de exclusão?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Tem certeza de que deseja realizar a operação clone?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Esta operação é bloqueada em Versão Demo!";
DGVocabulary._MSG["cookies_required"] = "Esta operação requer que o seu browser aceita cookies! Por favor, ligue aceitar cookies.";
DGVocabulary._MSG["exporting_alert"] = "Você quer exportar conteúdo datagrid para o arquivo";
DGVocabulary._MSG["extension_not_allowed"] = "Arquivos com extensão selecionada não são permitidos.";
DGVocabulary._MSG["need_upload_file"] = "Você deve fazer o upload de arquivos ou imagem antes de atualizar! Por favor, clique no link Upload.";
DGVocabulary._MSG["please_reenter"] = "Por favor, re-entrar!";
DGVocabulary._MSG["upload_file_size_alert"] = "O arquivo que você está tentando carregar é maior do que o tamanho máximo permitido: ";
