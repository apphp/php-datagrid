DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Du måste välja en eller flera rader för att genomföra denna operation!";
DGVocabulary._MSG["alert_perform_operation"] = "Är du säker på att du vill utföra denna operation?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Är du säker på att du vill utföra raderingen?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Är du säker på att du vill utföra klona operation?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Denna operation är blockerad i Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Denna funktion kräver att din webbläsare accepterar cookies! Var god aktivera cookies emot.";
DGVocabulary._MSG["exporting_alert"] = "Vill du exportera DataGrid innehåll i filen";
DGVocabulary._MSG["extension_not_allowed"] = "Filer med utvalda förlängning är inte tillåtna.";
DGVocabulary._MSG["need_upload_file"] = "Du måste ladda upp fil eller bild innan uppdatering! Klicka på Lägg upp länk.";
DGVocabulary._MSG["please_reenter"] = "Skriv in igen!";
DGVocabulary._MSG["upload_file_size_alert"] = "Filen du försöker ladda upp är större än maximalt tillåten storlek: ";
