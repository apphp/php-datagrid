DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "You have to select one or more rows to carry out this operation!";
DGVocabulary._MSG["alert_perform_operation"] = "Are you sure you want to carry out this operation?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Are you sure you want to carry out delete operation?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Are you sure you want to carry out clone operation?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "This operation is blocked in Demo Version!";
DGVocabulary._MSG["cookies_required"] = "This operation requires that your browser accepts cookies! Please turn on cookies accepting.";
DGVocabulary._MSG["exporting_alert"] = "Do you want to export datagrid content into the file";
DGVocabulary._MSG["extension_not_allowed"] = "Files with selected extension are not allowed.";
DGVocabulary._MSG["need_upload_file"] = "You must upload file or image before update! Please click on Upload link.";
DGVocabulary._MSG["please_reenter"] = "Please re-enter!";
DGVocabulary._MSG["upload_file_size_alert"] = "The file you are trying to upload is larger than the maximum allowed size: ";
