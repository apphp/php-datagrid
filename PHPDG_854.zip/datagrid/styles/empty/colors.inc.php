<?php
    $rowColor = array();
    $rowColor[0] = ''; // odd row color 
    $rowColor[1] = ''; // even row color
    $rowColor[2] = ''; // odd row color in main colomn
    $rowColor[3] = ''; // even row color in main colomn
    $rowColor[4] = ''; // row mouse over lighting 
    $rowColor[5] = ''; // on mouse click 
    $rowColor[6] = ''; // header (th main) column
    $rowColor[7] = ''; // selected row mouse over lighting
    $rowColor[8] = '';
    $rowColor[9] = '';
