DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Has de seleccionar una o més files per dur a terme aquesta operació!";
DGVocabulary._MSG["alert_perform_operation"] = "Esteu segur que voleu dur a terme aquesta operació?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Esteu segur que voleu dur a terme l'operació d'eliminació?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Esteu segur que voleu dur a terme operació de clonació?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Aquesta operació es bloqueja en Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Aquesta operació requereix que el seu navegador accepti cookies! Si us plau encengui d'acceptar cookies.";
DGVocabulary._MSG["exporting_alert"] = "Voleu exportar contingut DataGrid a l'arxiu";
DGVocabulary._MSG["extension_not_allowed"] = "Els arxius amb extensió seleccionada no estan permesos.";
DGVocabulary._MSG["need_upload_file"] = "Ha de carregar l'arxiu o la imatge abans de l'actualització! Si us plau, feu clic a l'enllaç [Carrega].";
DGVocabulary._MSG["please_reenter"] = "Torneu a entrar!";
DGVocabulary._MSG["upload_file_size_alert"] = "L'arxiu que està intentant carregar és més gran que la grandària màxima permesa: ";
