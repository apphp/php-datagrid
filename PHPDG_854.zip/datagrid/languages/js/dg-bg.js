DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Вие трябва да изберете един или повече реда за извършване на тази операция!";
DGVocabulary._MSG["alert_perform_operation"] = "Наистина ли искате да се извърши тази операция?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Наистина ли искате да изтриете извърши операция?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Наистина ли искате да извършва клонинг операция?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Тази операция е блокирана в Демо версия!";
DGVocabulary._MSG["cookies_required"] = "Тази операция изисква вашия браузър приема бисквитки! Моля, включете бисквитки приемане.";
DGVocabulary._MSG["exporting_alert"] = "Ли искате да експортирате DataGrid съдържание във файла";
DGVocabulary._MSG["extension_not_allowed"] = "Файлове с избрани разширение не са разрешени.";
DGVocabulary._MSG["need_upload_file"] = "Вие трябва да качите файл или снимка, преди да актуализира! Моля, кликнете върху линка [Качване].";
DGVocabulary._MSG["please_reenter"] = "Моля, въведете отново!";
DGVocabulary._MSG["upload_file_size_alert"] = "Файлът, който се опитвате да качите е по-голям от максималния позволен размер: ";
