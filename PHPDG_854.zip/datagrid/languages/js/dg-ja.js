DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "あなたはこの操作を実行する1つまたは複数の行を選択して！";
DGVocabulary._MSG["alert_perform_operation"] = "あなたはあなたがこの操作を実行するよろしいですか？";
DGVocabulary._MSG["alert_perform_operation_delete"] = "あなたは、削除操作を実行してもよろしいですか？";
DGVocabulary._MSG["alert_perform_operation_clone"] = "あなたはクローン操作を実行してもよろしいですか？";
DGVocabulary._MSG["alert_blocked_in_demo"] = "この操作は、デモ版でブロックされています！";
DGVocabulary._MSG["cookies_required"] = "この操作は、お使いのブラウザはクッキーを受け入れる必要があります！してくださいクッキーを受け入れるオンにします。";
DGVocabulary._MSG["exporting_alert"] = "あなたは、ファイルにデータグリッドの内容をエクスポートしたい";
DGVocabulary._MSG["extension_not_allowed"] = "選択した拡張子の付いたファイルは許可されません。";
DGVocabulary._MSG["need_upload_file"] = "あなたが更新する前にファイルや画像をアップロードする必要があります！アップロードのリンクをクリックしてください。";
DGVocabulary._MSG["please_reenter"] = "もう一度入力してください！";
DGVocabulary._MSG["upload_file_size_alert"] = "あなたがアップロードしようとしているファイルが最大許容サイズより大きいです。";
