DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Πρέπει να επιλέξετε μία ή περισσότερες σειρές για την εκτέλεση αυτής της λειτουργίας!";
DGVocabulary._MSG["alert_perform_operation"] = "Είστε σίγουροι ότι θέλετε να πραγματοποιήσει αυτήν την πράξη;";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Είστε σίγουροι ότι θέλετε να πραγματοποιήσει λειτουργία διαγραφής;";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Είστε σίγουροι ότι θέλετε να πραγματοποιήσει κλώνο λειτουργία;";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Αυτή η λειτουργία είναι αποκλεισμένη σε Demo έκδοση!";
DGVocabulary._MSG["cookies_required"] = "Αυτή η λειτουργία απαιτεί ότι ο browser σας δέχεται cookies! Παρακαλούμε ενεργοποιήστε τα cookies αποδοχή.";
DGVocabulary._MSG["exporting_alert"] = "Θέλετε να εξαγάγετε datagrid περιεχόμενο στο αρχείο";
DGVocabulary._MSG["extension_not_allowed"] = "Τα αρχεία με επιλεγμένη επέκταση δεν επιτρέπονται.";
DGVocabulary._MSG["need_upload_file"] = "Θα πρέπει να ανεβάσετε το αρχείο ή την εικόνα πριν από ενημέρωση! Κάντε κλικ στο σύνδεσμο Upload.";
DGVocabulary._MSG["please_reenter"] = "Παρακαλούμε να εισέλθει εκ νέου!";
DGVocabulary._MSG["upload_file_size_alert"] = "Το αρχείο που προσπαθείτε να ανεβάσετε είναι μεγαλύτερο από το μέγιστο επιτρεπόμενο μέγεθος: ";
