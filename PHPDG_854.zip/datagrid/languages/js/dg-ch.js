DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "你必须选择一个或多个行进行此操作！";
DGVocabulary._MSG["alert_perform_operation"] = "您是否确定要进行这项行动？";
DGVocabulary._MSG["alert_perform_operation_delete"] = "您是否确定要进行删除操作？";
DGVocabulary._MSG["alert_perform_operation_clone"] = "您是否确定要进行克隆操作？";
DGVocabulary._MSG["alert_blocked_in_demo"] = "此操作被阻止在演示版！";
DGVocabulary._MSG["cookies_required"] = "此操作要求您的浏览器接受Cookie的！请接受Cookie转机。";
DGVocabulary._MSG["exporting_alert"] = "你要导出DataGrid的内容到文件";
DGVocabulary._MSG["extension_not_allowed"] = "选定扩展名的文件是不允许的。";
DGVocabulary._MSG["need_upload_file"] = "更新之前，您必须上载文件或图像！请点击上传链接。";
DGVocabulary._MSG["please_reenter"] = "请重新输入！";
DGVocabulary._MSG["upload_file_size_alert"] = "您尝试上传文件大于允许的最大大小：";
