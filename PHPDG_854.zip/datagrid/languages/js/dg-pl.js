DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Musisz wybrać jeden lub więcej wierszy do przeprowadzenia tej operacji!";
DGVocabulary._MSG["alert_perform_operation"] = "Czy na pewno chcesz do przeprowadzenia tej operacji?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Czy na pewno chcesz przeprowadzić operację usuwania?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Czy na pewno chcesz przeprowadzić operację klonowania?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Ta operacja jest zablokowany Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Ta operacja wymaga, że Twoja przeglądarka akceptuje pliki cookie! Proszę włączyć przyjmowanie cookies.";
DGVocabulary._MSG["exporting_alert"] = "Czy chcesz wyeksportować zawartość DataGrid do pliku";
DGVocabulary._MSG["extension_not_allowed"] = "Pliki z wybranego rozszerzenia nie są dozwolone.";
DGVocabulary._MSG["need_upload_file"] = "Należy przesłać plik lub obraz przed update! Kliknij na link Upload.";
DGVocabulary._MSG["please_reenter"] = "Wpisz ponownie!";
DGVocabulary._MSG["upload_file_size_alert"] = "Plik, który próbujesz przesłać, jest większy niż maksymalny dopuszczalny rozmiar: ";
