<?php
    $rowColor = array();
    $rowColor[0] = '#fcfaf6'; // odd row color 
    $rowColor[1] = '#ffffff'; // even row color
    $rowColor[2] = '#ebeadb'; // odd row color in main colomn
    $rowColor[3] = '#ebeadb'; // even row color in main colomn
    $rowColor[4] = '#e2f3fc'; // row mouse over lighting 
    $rowColor[5] = '#fdfde7'; // on mouse click 
    $rowColor[6] = '#e2e0cb'; // header (th main) column
    $rowColor[7] = '#f9f9e3'; // selected row mouse over lighting
    $rowColor[8] = '#fcfaf6';
    $rowColor[9] = '#fcfaf6';
