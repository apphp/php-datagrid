DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Vous devez sélectionner une ou plusieurs lignes avant d'effectuer cette opération.";
DGVocabulary._MSG["alert_perform_operation"] = "Êtes-vous sûr de vouloir effectuer cette opération?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Êtes-vous sûr de vouloir effectuer l'opération de suppression?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Êtes-vous sûr de vouloir effectuer opération de clonage?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Cette opération est bloquée dans la version démo!";
DGVocabulary._MSG["cookies_required"] = "Cette opération nécessite que votre navigateur accepte les cookies. Veuillez effectuer vos réglages en conséquence.";
DGVocabulary._MSG["exporting_alert"] = "Voulez-vous exporter le contenu datagrid dans le fichier";
DGVocabulary._MSG["extension_not_allowed"] = "Les fichiers avec l'extension choisie ne sont pas autorisés.";
DGVocabulary._MSG["need_upload_file"] = "Vous devez télécharger le fichier ou l'image avant de faire la mise à jour. Merci de cliquer sur le lien Télécharger.";
DGVocabulary._MSG["please_reenter"] = "S'il vous plaît entrer de nouveau!";
DGVocabulary._MSG["upload_file_size_alert"] = "Le fichier que vous tentez de télécharger est plus grand que la taille maximale autorisée: ";
