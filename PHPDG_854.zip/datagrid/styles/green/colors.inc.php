<?php
    $rowColor = array();
    $rowColor[0] = '#ffffff'; // odd row color 
    $rowColor[1] = '#e4f5ef'; // even row color
    $rowColor[2] = '#ffffff'; // odd row color in main colomn
    $rowColor[3] = '#e4f5ef'; // even row color in main colomn
    $rowColor[4] = '#d4e5df'; // row mouse over lighting 
    $rowColor[5] = '#d4e5df'; // on mouse click 
    $rowColor[6] = '#c6d7cf'; // header (th main) column
    $rowColor[7] = '#d4e5df'; // selected row mouse over lighting
    $rowColor[8] = '#ffffff';
    $rowColor[9] = '#ffffff';
