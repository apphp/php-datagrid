DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Ai pentru a selecta una sau mai multe rânduri pentru a efectua această operaţiune!";
DGVocabulary._MSG["alert_perform_operation"] = "Sunteţi sigur că vreţi să efectueze această operaţiune?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Sunteţi sigur că doriţi să efectueze operaţiunea şterge?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Sunteţi sigur că doriţi să efectueze operaţiunea clona?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Această operaţiune este blocat în Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Această operaţiune presupune ca browser-ul acceptă cookie-uri! Vă rugăm să activaţi cookie-urile accepta.";
DGVocabulary._MSG["exporting_alert"] = "Vrei să exportaţi datagrid conţinutul în fisierul"; 
DGVocabulary._MSG["extension_not_allowed"] = "Fişiere cu extensie selectat nu sunt permise.";
DGVocabulary._MSG["need_upload_file"] = "Trebuie să vă încărcaţi fişier sau o imagine înainte de actualizare! Vă rugăm să faceţi clic pe link-ul Încărcaţi.";
DGVocabulary._MSG["please_reenter"] = "Vă rugăm să re-introduceţi!";
DGVocabulary._MSG["upload_file_size_alert"] = "Fişierul pe care încercaţi să încărcaţi este mai mare decât mărimea maximă permisă: ";
