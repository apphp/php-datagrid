DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "คุณจะต้องเลือกอย่างใดอย่างหนึ่งหรือมากกว่าแถวที่จะดำเนินการดำเนินการนี้";
DGVocabulary._MSG["alert_perform_operation"] = "คุณแน่ใจหรือว่าต้องการดำเนินการการดำเนินการนี้?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "คุณแน่ใจหรือว่าต้องการดำเนินการการดำเนินการลบ?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "คุณแน่ใจหรือว่าต้องการดำเนินการดำเนินการโคลน?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "การดำเนินการนี้ถูกบล็อกในรุ่นสาธิต!";
DGVocabulary._MSG["cookies_required"] = "การดำเนินการนี้ต้องใช้เบราว์เซอร์ของคุณที่ยอมรับคุกกี้! กรุณาเปิดยอมรับคุกกี้";
DGVocabulary._MSG["exporting_alert"] = "คุณต้องการที่จะส่งออกเนื้อหา DataGrid ลงในไฟล์";
DGVocabulary._MSG["extension_not_allowed"] = "ไฟล์ที่มีนามสกุลที่เลือกจะไม่ได้รับอนุญาต";
DGVocabulary._MSG["need_upload_file"] = "คุณต้องอัปโหลดไฟล์หรือภาพก่อนที่จะปรับปรุง! กรุณาคลิกที่ลิงค์อัพโหลด";
DGVocabulary._MSG["please_reenter"] = "กรุณากรอก!";
DGVocabulary._MSG["upload_file_size_alert"] = "แฟ้มที่คุณกำลังพยายามอัปโหลดมีขนาดใหญ่กว่าขนาดที่ได้รับอนุญาตสูงสุด: ";
