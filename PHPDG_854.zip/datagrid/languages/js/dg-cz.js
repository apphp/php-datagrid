DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Musíte vybrat jeden nebo více řádků provést tuto operaci!";
DGVocabulary._MSG["alert_perform_operation"] = "Jste si jisti, že chcete provést tuto operaci?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Jste si jisti, že chcete provádět operaci odstranění?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Jste si jisti, že chcete provádět operaci klon?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Tato operace je blokována v Demo verzi!";
DGVocabulary._MSG["cookies_required"] = "Tato operace vyžaduje, aby Váš prohlížeč akceptuje cookies! Prosím, zapněte cookies přijímá.";
DGVocabulary._MSG["exporting_alert"] = "Chcete exportovat DataGrid obsah do souboru";
DGVocabulary._MSG["extension_not_allowed"] = "Soubory s příponou vybraného nejsou povoleny.";
DGVocabulary._MSG["need_upload_file"] = "Musíte nahrát soubor nebo image před update! Prosím, klikněte na odkaz Nahrát.";
DGVocabulary._MSG["please_reenter"] = "Zadejte prosím znovu!";
DGVocabulary._MSG["upload_file_size_alert"] = "Soubor, který se pokoušíte nahrát, je větší než maximální povolená velikost: ";
