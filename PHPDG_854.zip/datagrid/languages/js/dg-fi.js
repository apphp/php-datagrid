DGVocabulary = function () {

};

DGVocabulary._MSG = {};
DGVocabulary._MSG["alert_select_row"] = "Sinun täytyy valita yksi tai useampia rivejä suorittaa tämän toiminnon!";
DGVocabulary._MSG["alert_perform_operation"] = "Oletko varma että haluat tehdä tämän toiminnon?";
DGVocabulary._MSG["alert_perform_operation_delete"] = "Oletko varma että haluat suorittaa poistamistoiminnon?";
DGVocabulary._MSG["alert_perform_operation_clone"] = "Oletko varma että haluat suorittaa klooni toimintaa?";
DGVocabulary._MSG["alert_blocked_in_demo"] = "Tämä toiminto on estetty Demo Version!";
DGVocabulary._MSG["cookies_required"] = "Tämä toiminto edellyttää, että selaimesi hyväksyy evästeet! Ota päälle evästeet hyväksytään.";
DGVocabulary._MSG["exporting_alert"] = "Haluatko viedä DataGrid sisällön tiedostoon";
DGVocabulary._MSG["extension_not_allowed"] = "Tiedostot valittujen laajennus eivät ole sallittuja.";
DGVocabulary._MSG["need_upload_file"] = "Sinun täytyy ladata tiedosto tai kuva ennen päivitystä! Klikkaa Lataa-linkkiä.";
DGVocabulary._MSG["please_reenter"] = "Anna uudelleen!";
DGVocabulary._MSG["upload_file_size_alert"] = "Tiedosto, jota yrität ladata on suurempi kuin suurin sallittu koko: ";
