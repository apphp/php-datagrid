<?php

/***
 *  This is an example of DataGrid extention 
 *
**/

class DataGridChild extends DataGrid
{
  
    // Inheritance of DataGridChild
    
    //--------------------------------------------------------------------------
    // draw in tabular layout
    //--------------------------------------------------------------------------
    function DrawTabular(){

        // Your code here....

    }    
    
}
