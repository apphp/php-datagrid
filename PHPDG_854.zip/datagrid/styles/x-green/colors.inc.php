<?php
    $rowColor = array();
    $rowColor[0] = '#e9f7f7'; // odd row color 
    $rowColor[1] = '#ffffff'; // even row color
    $rowColor[2] = '#9dd7d7'; // odd row color in main colomn
    $rowColor[3] = '#ade7e7'; // even row color in main colomn    
    $rowColor[4] = '#fdfde7'; // row mouse over lighting 
    $rowColor[5] = '#e4f3f3'; // on mouse click 
    $rowColor[6] = '#fcfaf6'; // header (th main) column
    $rowColor[7] = '#f9f9e3'; // selected row mouse over lighting
    $rowColor[8] = '#85c2c2'; // selected odd row
    $rowColor[9] = '#95d2d2'; // selected eved row
