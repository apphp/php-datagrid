<?php
    $rowColor = array();
    $rowColor[0] = '#f7f9fb'; // odd row color 
    $rowColor[1] = '#ffffff'; // even row color
    $rowColor[2] = '#d9e3f1'; // odd row color in main colomn
    $rowColor[3] = '#e4ecf7'; // even row color in main colomn
    $rowColor[4] = '#FEFFE8'; // row mouse over lighting 
    $rowColor[5] = '#FEFFE8'; // on mouse click 
    $rowColor[6] = '#cdd9ea'; // header (th main) column
    $rowColor[7] = '#FEFFE8'; // selected row mouse over lighting
    $rowColor[8] = '#f7f9fb';
    $rowColor[9] = '#f7f9fb';
